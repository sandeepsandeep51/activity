from django.urls import path
from . import views

urlpatterns = [
    path('dashboard/', views.staff_dashboard, name='staff_dashboard'),
    path('activity-planner/', views.staff_activity_planner, name='staff_activity_planner'),
    path('activity-hours/', views.staff_activity_hours, name='staff_activity_hours'),
    path('shoptalk/', views.staff_shoptalk, name='staff_shoptalk'),
    path('leave-requests/', views.leave_requests, name='leave_requests'),
    path('student/<int:student_id>/', views.student_details, name='student_details'),
]