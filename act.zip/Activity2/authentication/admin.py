from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User, Center, Course, UserProfile

class UserProfileInline(admin.StackedInline):
    model = UserProfile
    can_delete = False
    verbose_name_plural = 'Profile'

class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'first_name', 'last_name', 'role', 'phone', 'get_center', 'get_course')
    inlines = (UserProfileInline,)
    
    def get_center(self, obj):
        return obj.profile.center if hasattr(obj, 'profile') else None
    get_center.short_description = 'Center'
    
    def get_course(self, obj):
        return obj.profile.course if hasattr(obj, 'profile') else None
    get_course.short_description = 'Course'

    fieldsets = (
        (None, {'fields': ('username', 'password')}),
        ('Personal info', {'fields': ('first_name', 'last_name', 'email', 'phone', 'address')}),
        ('Permissions', {'fields': ('is_active', 'is_staff', 'is_superuser', 'role', 'groups', 'user_permissions')}),
        ('Important dates', {'fields': ('last_login', 'date_joined')}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'password1', 'password2', 'email', 'role', 'phone', 'address'),
        }),
    )

class CenterAdmin(admin.ModelAdmin):
    list_display = ('name', 'location')
    search_fields = ('name', 'location')

class CourseAdmin(admin.ModelAdmin):
    list_display = ('name', 'center')
    list_filter = ('center',)
    search_fields = ('name', 'description')

admin.site.register(User, CustomUserAdmin)
admin.site.register(Center, CenterAdmin)
admin.site.register(Course, CourseAdmin)
