from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages  # Add this import
from authentication.models import User
from student.models import ActivityLog

@login_required
def staff_dashboard(request):
    if request.user.role != 'staff':
        return redirect('login')
    
    # Get all students
    students = User.objects.filter(role='student')
    pending_verifications = ActivityLog.objects.filter(verification_status='pending').count()
    
    context = {
        'pending_verifications': pending_verifications,
        'total_students': students.count(),
        'active_courses': 0,
        'recent_activities': ActivityLog.objects.count(),
        'students': students  # Add students to context
    }
    return render(request, 'staff/dashboard.html', context)

@login_required
def staff_profile(request):
    if request.user.role != 'staff':
        return redirect('login')
    return render(request, 'staff/profile.html')

@login_required
def student_details(request, student_id):
    if request.user.role != 'staff':
        return redirect('login')
    
    student = get_object_or_404(User, id=student_id, role='student')
    activity_logs = ActivityLog.objects.filter(user=student).order_by('-date')
    
    context = {
        'student': student,
        'activity_logs': activity_logs
    }
    return render(request, 'staff/student_details.html', context)

@login_required
def leave_requests(request):
    return render(request, 'staff/leave_requests.html')

@login_required
def staff_shoptalk(request):
    return render(request, 'staff/shoptalk.html')

@login_required
def staff_activity_planner(request):
    if request.user.role != 'staff':
        return redirect('login')
    
    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'clear_all':
            ActivityLog.objects.all().delete()
            messages.success(request, 'All activity logs cleared successfully!')
        else:
            log_id = request.POST.get('log_id')
            if log_id:
                log = ActivityLog.objects.get(id=log_id)
                log.verification_status = action
                log.verified_by = request.user
                log.save()
                messages.success(request, f'Activity log {action} successfully!')
            
    activity_logs = ActivityLog.objects.all().order_by('-date')
    context = {
        'activity_logs': activity_logs
    }
    return render(request, 'staff/activity_planner.html', context)

@login_required
def staff_verify_activity(request, log_id):
    if request.user.role != 'staff':
        return redirect('login')
        
    if request.method == 'POST':
        log = get_object_or_404(ActivityLog, id=log_id)
        log.verification_status = request.POST.get('verification_status')
        log.staff_comments = request.POST.get('staff_comments')
        log.verified_by = request.user
        log.save()
        
    return redirect('staff_activity_planner')

@login_required
def staff_activity_hours(request):
    return render(request, 'staff/activity_hours.html')
