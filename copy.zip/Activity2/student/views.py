from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from datetime import datetime
from student.models import ActivityLog

@login_required
def student_dashboard(request):
    if request.user.role != 'student':
        return redirect('login')
    context = {
        'pending_leaves': 3,
        'active_projects': 2,
        'shoptalk_sessions': 5,
        'activity_hours': 24
    }
    return render(request, 'student/dashboard.html', context)

@login_required
def student_profile(request):
    return render(request, 'student/profile.html')

@login_required
def student_leave(request):
    return render(request, 'student/leave.html')

@login_required
def student_shoptalk(request):
    return render(request, 'student/shoptalk.html')

@login_required
def student_projects(request):
    return render(request, 'student/projects.html')

@login_required
def student_latecoming(request):
    return render(request, 'student/latecoming.html')

@login_required
def activity_planner(request):
    if request.user.role != 'student':
        return redirect('login')
    
    current_datetime = datetime.now()
    
    edit_log = None
    display_datetime = current_datetime
    if request.GET.get('edit'):
        edit_log = ActivityLog.objects.get(id=request.GET.get('edit'))
        # Use the original log's date for display when reworking
        display_datetime = datetime.combine(edit_log.date, current_datetime.time())
        
    if request.method == 'POST':
        log_id = request.POST.get('log_id')
        if log_id:
            # Update existing log
            log = ActivityLog.objects.get(id=log_id)
            log.thought = request.POST.get('thought')
            log.main_mistake = request.POST.get('main_mistake')
            log.critical_observation = request.POST.get('critical_observation')
            log.main_achievement = request.POST.get('main_achievement')
            log.plan_tomorrow = request.POST.get('plan_tomorrow')
            log.verification_status = 'pending'
            # Keep the original date when updating
            log.save(update_fields=['thought', 'main_mistake', 'critical_observation', 
                                  'main_achievement', 'plan_tomorrow', 'verification_status'])
        else:
            # Create new log
            ActivityLog.objects.create(
                user=request.user,
                thought=request.POST.get('thought'),
                main_mistake=request.POST.get('main_mistake'),
                critical_observation=request.POST.get('critical_observation'),
                main_achievement=request.POST.get('main_achievement'),
                plan_tomorrow=request.POST.get('plan_tomorrow'),
                date=current_datetime.date()
            )
        messages.success(request, 'Activity log submitted successfully!')
        return redirect('activity_planner')
    
    user_logs = ActivityLog.objects.filter(user=request.user).order_by('-date')
    context = {
        'user_logs': user_logs,
        'edit_log': edit_log,
        'current_date': display_datetime.strftime('%B %d, %Y'),
        'current_day': display_datetime.strftime('%A'),
        'current_time': current_datetime.strftime('%I:%M %p')
    }
    return render(request, 'student/activity_planner.html', context)

@login_required
def activity_hours(request):
    return render(request, 'student/activity_hours.html')

@login_required
def feedback(request):
    return render(request, 'student/feedback.html')
