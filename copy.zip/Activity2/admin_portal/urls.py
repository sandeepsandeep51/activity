from django.urls import path
from . import views

urlpatterns = [
    path('dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('profile/', views.admin_profile, name='admin_profile'),
    path('staff-management/', views.staff_management, name='staff_management'),
    path('student-management/', views.student_management, name='student_management'),
    path('leave-management/', views.leave_management, name='leave_management'),
    path('activity-management/', views.activity_management, name='activity_management'),
    path('reports/', views.reports, name='reports'),
]